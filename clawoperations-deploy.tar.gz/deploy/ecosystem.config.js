module.exports = {
  apps: [
    {
      name: 'clawoperations-server',
      script: 'dist/index.js',
      cwd: '/var/www/clawoperations/web/server',
      instances: 1,
      exec_mode: 'fork',
      autorestart: true,
      watch: false,
      max_memory_restart: '500M',
      env: {
        NODE_ENV: 'production',
        PORT: 3001,
      },
      env_file: '/var/www/clawoperations/web/server/.env.production',
      error_file: '/var/log/pm2/clawoperations-error.log',
      out_file: '/var/log/pm2/clawoperations-out.log',
      log_date_format: 'YYYY-MM-DD HH:mm:ss',
      merge_logs: true,
    },
  ],
};
