"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClawPublisher = exports.createLogger = exports.SchedulerService = exports.PublishService = exports.OAUTH_SCOPES = exports.DouyinAuth = exports.DouyinClient = void 0;
const douyin_client_1 = require("./api/douyin-client");
Object.defineProperty(exports, "DouyinClient", { enumerable: true, get: function () { return douyin_client_1.DouyinClient; } });
const auth_1 = require("./api/auth");
Object.defineProperty(exports, "DouyinAuth", { enumerable: true, get: function () { return auth_1.DouyinAuth; } });
Object.defineProperty(exports, "OAUTH_SCOPES", { enumerable: true, get: function () { return auth_1.OAUTH_SCOPES; } });
const publish_service_1 = require("./services/publish-service");
Object.defineProperty(exports, "PublishService", { enumerable: true, get: function () { return publish_service_1.PublishService; } });
const scheduler_service_1 = require("./services/scheduler-service");
Object.defineProperty(exports, "SchedulerService", { enumerable: true, get: function () { return scheduler_service_1.SchedulerService; } });
const logger_1 = require("./utils/logger");
Object.defineProperty(exports, "createLogger", { enumerable: true, get: function () { return logger_1.createLogger; } });
// 导出所有类型
__exportStar(require("./models/types"), exports);
const logger = (0, logger_1.createLogger)('ClawPublisher');
/**
 * ClawPublisher - 抖音视频发布主类
 *
 * 提供统一的对外接口，供 ClawBot 或其他系统集成调用
 */
class ClawPublisher {
    /**
     * 创建 ClawPublisher 实例
     * @param config 抖音配置
     */
    constructor(config) {
        // 初始化客户端
        this.client = new douyin_client_1.DouyinClient();
        // 初始化认证模块
        const oauthConfig = {
            clientKey: config.clientKey,
            clientSecret: config.clientSecret,
            redirectUri: config.redirectUri,
        };
        this.auth = new auth_1.DouyinAuth(this.client, oauthConfig);
        // 如果有预置的 token，设置它
        if (config.accessToken && config.refreshToken && config.openId) {
            this.auth.setTokenInfo({
                accessToken: config.accessToken,
                refreshToken: config.refreshToken,
                expiresAt: Date.now() + 7200 * 1000, // 默认 2 小时
                openId: config.openId,
                scope: '',
            });
        }
        // 初始化服务
        this.publishService = new publish_service_1.PublishService(this.client, this.auth);
        this.schedulerService = new scheduler_service_1.SchedulerService(this.publishService);
        logger.info('ClawPublisher 初始化完成');
    }
    // ==================== 认证相关 ====================
    /**
     * 获取授权页面 URL
     * @param scopes 授权作用域
     * @param state 状态参数
     * @returns 授权 URL
     */
    getAuthUrl(scopes, state) {
        return this.auth.getAuthorizationUrl(scopes, state);
    }
    /**
     * 处理授权回调，获取 Token
     * @param code 授权码
     * @returns Token 信息
     */
    async handleAuthCallback(code) {
        return this.auth.getAccessToken(code);
    }
    /**
     * 刷新 Token
     * @returns 新的 Token 信息
     */
    async refreshToken() {
        return this.auth.refreshAccessToken();
    }
    /**
     * 检查 Token 是否有效
     * @returns 是否有效
     */
    isTokenValid() {
        return this.auth.isTokenValid();
    }
    /**
     * 获取当前 Token 信息
     * @returns Token 信息
     */
    getTokenInfo() {
        return this.auth.getTokenInfo();
    }
    // ==================== 视频上传 ====================
    /**
     * 上传视频文件
     * @param filePath 视频文件路径
     * @param onProgress 进度回调
     * @returns 视频 ID
     */
    async uploadVideo(filePath, onProgress) {
        return this.publishService.uploadVideo(filePath, onProgress);
    }
    /**
     * 从 URL 上传视频
     * @param videoUrl 视频 URL
     * @returns 视频 ID
     */
    async uploadFromUrl(videoUrl) {
        return this.publishService.publishVideo({
            videoPath: videoUrl,
            isRemoteUrl: true,
        }).then(result => {
            if (!result.success || !result.videoId) {
                throw new Error(result.error || '上传失败');
            }
            return result.videoId;
        });
    }
    // ==================== 视频发布 ====================
    /**
     * 发布视频（上传 + 发布）
     * @param config 发布任务配置
     * @returns 发布结果
     */
    async publishVideo(config) {
        return this.publishService.publishVideo(config);
    }
    /**
     * 发布已上传的视频
     * @param videoId 视频 ID
     * @param options 发布选项
     * @returns 发布结果
     */
    async publishUploadedVideo(videoId, options) {
        return this.publishService.publishUploadedVideo(videoId, options);
    }
    /**
     * 下载远程视频并发布
     * @param videoUrl 视频 URL
     * @param options 发布选项
     * @returns 发布结果
     */
    async downloadAndPublish(videoUrl, options) {
        return this.publishService.downloadAndPublish(videoUrl, options);
    }
    // ==================== 定时发布 ====================
    /**
     * 定时发布视频
     * @param config 发布任务配置
     * @param publishTime 发布时间
     * @returns 任务信息
     */
    scheduleVideo(config, publishTime) {
        return this.schedulerService.schedulePublish(config, publishTime);
    }
    /**
     * 取消定时任务
     * @param taskId 任务 ID
     * @returns 是否成功取消
     */
    cancelSchedule(taskId) {
        return this.schedulerService.cancelSchedule(taskId);
    }
    /**
     * 列出所有定时任务
     * @returns 任务列表
     */
    listScheduledTasks() {
        return this.schedulerService.listScheduledTasks();
    }
    // ==================== 视频管理 ====================
    /**
     * 查询视频状态
     * @param videoId 视频 ID
     * @returns 视频状态
     */
    async queryVideoStatus(videoId) {
        return this.publishService.queryVideoStatus(videoId);
    }
    /**
     * 删除视频
     * @param videoId 视频 ID
     */
    async deleteVideo(videoId) {
        return this.publishService.deleteVideo(videoId);
    }
    // ==================== 工具方法 ====================
    /**
     * 停止所有定时任务
     */
    stop() {
        this.schedulerService.stopAll();
        logger.info('ClawPublisher 已停止');
    }
}
exports.ClawPublisher = ClawPublisher;
// 默认导出
exports.default = ClawPublisher;
//# sourceMappingURL=index.js.map