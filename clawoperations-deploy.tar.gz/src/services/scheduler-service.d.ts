import { PublishService } from './publish-service';
import { PublishTaskConfig, ScheduleResult } from '../models/types';
/**
 * 定时发布调度服务
 */
export declare class SchedulerService {
    private publishService;
    private tasks;
    constructor(publishService: PublishService);
    /**
     * 注册定时发布任务
     * @param config 发布任务配置
     * @param publishTime 发布时间
     * @returns 任务信息
     */
    schedulePublish(config: PublishTaskConfig, publishTime: Date): ScheduleResult;
    /**
     * 取消定时任务
     * @param taskId 任务 ID
     * @returns 是否成功取消
     */
    cancelSchedule(taskId: string): boolean;
    /**
     * 列出所有待发布的任务
     * @returns 任务列表
     */
    listScheduledTasks(): ScheduleResult[];
    /**
     * 获取任务详情
     * @param taskId 任务 ID
     * @returns 任务信息
     */
    getTask(taskId: string): ScheduleResult | null;
    /**
     * 执行定时任务
     * @param taskId 任务 ID
     */
    private executeTask;
    /**
     * 将日期转换为 cron 表达式
     * @param date 日期
     * @returns cron 表达式
     */
    private dateToCron;
    /**
     * 清理已完成的任务
     */
    cleanupCompletedTasks(): void;
    /**
     * 停止所有任务
     */
    stopAll(): void;
}
export default SchedulerService;
//# sourceMappingURL=scheduler-service.d.ts.map