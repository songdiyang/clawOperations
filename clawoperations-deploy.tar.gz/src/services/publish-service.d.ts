import { DouyinClient } from '../api/douyin-client';
import { DouyinAuth } from '../api/auth';
import { PublishTaskConfig, PublishResult, VideoPublishOptions, UploadProgress } from '../models/types';
/**
 * 发布服务 - 业务编排层
 */
export declare class PublishService {
    private videoUpload;
    private videoPublish;
    private auth;
    constructor(client: DouyinClient, auth: DouyinAuth);
    /**
     * 一站式发布视频（上传 + 发布）
     * @param config 发布任务配置
     * @returns 发布结果
     */
    publishVideo(config: PublishTaskConfig): Promise<PublishResult>;
    /**
     * 仅上传视频（不发布）
     * @param filePath 视频文件路径
     * @param onProgress 进度回调
     * @returns 视频 ID
     */
    uploadVideo(filePath: string, onProgress?: (progress: UploadProgress) => void): Promise<string>;
    /**
     * 发布已上传的视频
     * @param videoId 视频 ID
     * @param options 发布选项
     * @returns 发布结果
     */
    publishUploadedVideo(videoId: string, options?: VideoPublishOptions): Promise<PublishResult>;
    /**
     * 下载远程视频并发布
     * @param videoUrl 视频 URL
     * @param options 发布选项
     * @returns 发布结果
     */
    downloadAndPublish(videoUrl: string, options?: VideoPublishOptions): Promise<PublishResult>;
    /**
     * 查询视频状态
     * @param videoId 视频 ID
     * @returns 视频状态
     */
    queryVideoStatus(videoId: string): Promise<{
        status: string;
        shareUrl?: string;
        createTime?: number;
    }>;
    /**
     * 删除视频
     * @param videoId 视频 ID
     */
    deleteVideo(videoId: string): Promise<void>;
    /**
     * 下载文件
     * @param url 文件 URL
     * @param destPath 目标路径
     */
    private downloadFile;
}
export default PublishService;
//# sourceMappingURL=publish-service.d.ts.map