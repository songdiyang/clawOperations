import { DouyinClient } from './douyin-client';
import { DouyinAuth } from './auth';
import { UploadConfig } from '../models/types';
/**
 * 视频上传模块
 */
export declare class VideoUpload {
    private client;
    private auth;
    constructor(client: DouyinClient, auth: DouyinAuth);
    /**
     * 上传视频（自动选择上传方式）
     * @param filePath 视频文件路径
     * @param config 上传配置
     * @returns 视频 ID
     */
    uploadVideo(filePath: string, config?: UploadConfig): Promise<string>;
    /**
     * 直接上传（小文件，小于 128MB）
     * @param filePath 视频文件路径
     * @param config 上传配置
     * @returns 视频 ID
     */
    private uploadVideoDirect;
    /**
     * 分片上传（大文件，大于 128MB）
     * @param filePath 视频文件路径
     * @param config 上传配置
     * @returns 视频 ID
     */
    private uploadVideoChunked;
    /**
     * 初始化分片上传
     * @param totalSize 文件总大小
     * @param fileName 文件名
     * @returns upload_id
     */
    private initChunkUpload;
    /**
     * 上传单个分片
     * @param uploadId 上传 ID
     * @param chunkData 分片数据
     * @param partNumber 分片序号
     */
    private uploadChunk;
    /**
     * 完成分片上传
     * @param uploadId 上传 ID
     * @returns 上传完成响应
     */
    private completeChunkUpload;
    /**
     * 从远程 URL 上传视频
     * @param videoUrl 视频 URL
     * @returns 视频 ID
     */
    uploadFromUrl(videoUrl: string): Promise<string>;
}
export default VideoUpload;
//# sourceMappingURL=video-upload.d.ts.map