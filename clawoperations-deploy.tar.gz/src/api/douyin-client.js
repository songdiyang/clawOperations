"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DouyinApiException = exports.DouyinClient = void 0;
const axios_1 = __importDefault(require("axios"));
const retry_1 = require("../utils/retry");
const logger_1 = require("../utils/logger");
const default_1 = require("../../config/default");
const logger = (0, logger_1.createLogger)('DouyinClient');
/**
 * 抖音 API 客户端
 */
class DouyinClient {
    constructor() {
        this.accessToken = null;
        this.client = axios_1.default.create({
            baseURL: default_1.API_CONFIG.BASE_URL,
            timeout: 30000,
            headers: {
                'Content-Type': 'application/json',
            },
        });
        this.setupInterceptors();
    }
    /**
     * 设置访问令牌
     * @param token 访问令牌
     */
    setAccessToken(token) {
        this.accessToken = token;
    }
    /**
     * 获取当前访问令牌
     * @returns 访问令牌
     */
    getAccessToken() {
        return this.accessToken;
    }
    /**
     * 设置请求拦截器
     */
    setupInterceptors() {
        // 请求拦截器
        this.client.interceptors.request.use((config) => {
            // 自动注入 access_token
            if (this.accessToken && config.params) {
                config.params.access_token = this.accessToken;
            }
            logger.debug(`API 请求: ${config.method?.toUpperCase()} ${config.url}`);
            return config;
        }, (error) => {
            logger.error(`请求拦截器错误: ${error.message}`);
            return Promise.reject(error);
        });
        // 响应拦截器
        this.client.interceptors.response.use((response) => {
            logger.debug(`API 响应: ${response.config.url} - ${response.status}`);
            // 检查抖音 API 错误码
            const data = response.data;
            if (data && typeof data === 'object' && 'data' in data) {
                // 某些接口错误码在 data 中
                const errorData = data;
                if (errorData.data?.error_code && errorData.data.error_code !== 0) {
                    const error = {
                        code: errorData.data.error_code,
                        message: errorData.data.description || '未知错误',
                    };
                    throw new DouyinApiException(error);
                }
            }
            return response;
        }, (error) => {
            return this.handleError(error);
        });
    }
    /**
     * 处理 API 错误
     * @param error Axios 错误
     */
    handleError(error) {
        if (error.response) {
            const { status, data } = error.response;
            logger.error(`API 错误: ${status} - ${JSON.stringify(data)}`);
            // 抖音 API 特定错误
            if (data && data.code) {
                throw new DouyinApiException(data);
            }
            // HTTP 状态码错误
            throw new Error(`HTTP ${status}: ${error.message}`);
        }
        else if (error.request) {
            logger.error(`网络错误: ${error.message}`);
            throw new Error(`网络错误: ${error.message}`);
        }
        else {
            logger.error(`请求配置错误: ${error.message}`);
            throw new Error(`请求配置错误: ${error.message}`);
        }
    }
    /**
     * 发送 GET 请求
     * @param url 请求地址
     * @param config 请求配置
     * @param retryConfig 重试配置
     */
    async get(url, config, retryConfig) {
        return (0, retry_1.withRetry)(async () => {
            const response = await this.client.get(url, config);
            return response.data.data;
        }, {
            ...default_1.RETRY_CONFIG,
            ...retryConfig,
            shouldRetry: (error) => this.shouldRetry(error),
        });
    }
    /**
     * 发送 POST 请求
     * @param url 请求地址
     * @param data 请求数据
     * @param config 请求配置
     * @param retryConfig 重试配置
     */
    async post(url, data, config, retryConfig) {
        return (0, retry_1.withRetry)(async () => {
            const response = await this.client.post(url, data, config);
            return response.data.data;
        }, {
            ...default_1.RETRY_CONFIG,
            ...retryConfig,
            shouldRetry: (error) => this.shouldRetry(error),
        });
    }
    /**
     * 发送 POST 请求（multipart/form-data）
     * @param url 请求地址
     * @param formData FormData 对象
     * @param config 请求配置
     * @param retryConfig 重试配置
     */
    async postForm(url, formData, config, retryConfig) {
        return (0, retry_1.withRetry)(async () => {
            const response = await this.client.post(url, formData, {
                ...config,
                headers: {
                    ...config?.headers,
                    'Content-Type': 'multipart/form-data',
                },
            });
            return response.data.data;
        }, {
            ...default_1.RETRY_CONFIG,
            ...retryConfig,
            shouldRetry: (error) => this.shouldRetry(error),
        });
    }
    /**
     * 判断是否应该重试
     * @param error 错误对象
     */
    shouldRetry(error) {
        // 抖音 API 限流错误码
        const RATE_LIMIT_CODES = [429, 10001, 10002];
        if (error instanceof DouyinApiException) {
            return RATE_LIMIT_CODES.includes(error.error.code);
        }
        // 网络错误和超时
        if (error.message.includes('网络错误') ||
            error.message.includes('timeout') ||
            error.message.includes('ECONNRESET')) {
            return true;
        }
        return false;
    }
}
exports.DouyinClient = DouyinClient;
/**
 * 抖音 API 异常
 */
class DouyinApiException extends Error {
    constructor(error) {
        super(`[${error.code}] ${error.message}`);
        this.error = error;
        this.name = 'DouyinApiException';
    }
}
exports.DouyinApiException = DouyinApiException;
exports.default = DouyinClient;
//# sourceMappingURL=douyin-client.js.map