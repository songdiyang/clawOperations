import { AxiosRequestConfig } from 'axios';
import FormData from 'form-data';
import { DouyinApiError, RetryConfig } from '../models/types';
/**
 * 抖音 API 客户端
 */
export declare class DouyinClient {
    private client;
    private accessToken;
    constructor();
    /**
     * 设置访问令牌
     * @param token 访问令牌
     */
    setAccessToken(token: string): void;
    /**
     * 获取当前访问令牌
     * @returns 访问令牌
     */
    getAccessToken(): string | null;
    /**
     * 设置请求拦截器
     */
    private setupInterceptors;
    /**
     * 处理 API 错误
     * @param error Axios 错误
     */
    private handleError;
    /**
     * 发送 GET 请求
     * @param url 请求地址
     * @param config 请求配置
     * @param retryConfig 重试配置
     */
    get<T>(url: string, config?: AxiosRequestConfig, retryConfig?: Partial<RetryConfig>): Promise<T>;
    /**
     * 发送 POST 请求
     * @param url 请求地址
     * @param data 请求数据
     * @param config 请求配置
     * @param retryConfig 重试配置
     */
    post<T>(url: string, data?: unknown, config?: AxiosRequestConfig, retryConfig?: Partial<RetryConfig>): Promise<T>;
    /**
     * 发送 POST 请求（multipart/form-data）
     * @param url 请求地址
     * @param formData FormData 对象
     * @param config 请求配置
     * @param retryConfig 重试配置
     */
    postForm<T>(url: string, formData: FormData, config?: AxiosRequestConfig, retryConfig?: Partial<RetryConfig>): Promise<T>;
    /**
     * 判断是否应该重试
     * @param error 错误对象
     */
    private shouldRetry;
}
/**
 * 抖音 API 异常
 */
export declare class DouyinApiException extends Error {
    readonly error: DouyinApiError;
    constructor(error: DouyinApiError);
}
export default DouyinClient;
//# sourceMappingURL=douyin-client.d.ts.map