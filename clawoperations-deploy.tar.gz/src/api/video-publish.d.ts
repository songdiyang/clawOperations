import { DouyinClient } from './douyin-client';
import { DouyinAuth } from './auth';
import { VideoPublishOptions, VideoCreateResponse } from '../models/types';
/**
 * 视频发布模块
 */
export declare class VideoPublish {
    private client;
    private auth;
    constructor(client: DouyinClient, auth: DouyinAuth);
    /**
     * 创建并发布视频
     * @param videoId 视频 ID（上传后获得）
     * @param options 发布选项
     * @returns 发布结果
     */
    createVideo(videoId: string, options?: VideoPublishOptions): Promise<VideoCreateResponse>;
    /**
     * 构建发布参数
     * @param videoId 视频 ID
     * @param options 发布选项
     * @returns API 请求参数
     */
    private buildPublishParams;
    /**
     * 查询视频状态
     * @param videoId 视频 ID
     * @returns 视频状态
     */
    queryVideoStatus(videoId: string): Promise<{
        status: string;
        shareUrl?: string;
        createTime?: number;
    }>;
    /**
     * 删除视频
     * @param videoId 视频 ID
     */
    deleteVideo(videoId: string): Promise<void>;
}
export default VideoPublish;
//# sourceMappingURL=video-publish.d.ts.map