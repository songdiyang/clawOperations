import { DouyinClient } from './douyin-client';
import { OAuthConfig, TokenInfo } from '../models/types';
/**
 * OAuth 认证作用域
 */
export declare const OAUTH_SCOPES: {
    readonly VIDEO_CREATE: "video.create";
    readonly VIDEO_UPLOAD: "video.upload";
    readonly VIDEO_DATA: "video.data";
    readonly USER_INFO: "user.info";
};
/**
 * 抖音 OAuth 认证模块
 */
export declare class DouyinAuth {
    private client;
    private config;
    private tokenInfo;
    constructor(client: DouyinClient, config: OAuthConfig);
    /**
     * 生成授权页面 URL
     * @param scopes 授权作用域数组
     * @param state 状态参数（可选，用于防止 CSRF）
     * @returns 授权页面 URL
     */
    getAuthorizationUrl(scopes?: string[], state?: string): string;
    /**
     * 使用授权码换取 access_token
     * @param authCode 授权码
     * @returns Token 信息
     */
    getAccessToken(authCode: string): Promise<TokenInfo>;
    /**
     * 刷新 access_token
     * @param refreshToken 刷新令牌（可选，默认使用当前存储的）
     * @returns 新的 Token 信息
     */
    refreshAccessToken(refreshToken?: string): Promise<TokenInfo>;
    /**
     * 检查 token 是否有效
     * @returns 是否有效
     */
    isTokenValid(): boolean;
    /**
     * 确保 token 有效（如果过期则自动刷新）
     */
    ensureTokenValid(): Promise<void>;
    /**
     * 获取当前 token 信息
     * @returns Token 信息
     */
    getTokenInfo(): TokenInfo | null;
    /**
     * 设置 token 信息（用于从存储中恢复）
     * @param tokenInfo Token 信息
     */
    setTokenInfo(tokenInfo: TokenInfo): void;
    /**
     * 解析 Token 响应
     * @param response API 响应
     * @returns Token 信息
     */
    private parseTokenResponse;
}
export default DouyinAuth;
//# sourceMappingURL=auth.d.ts.map