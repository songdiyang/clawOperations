import { VideoPublishOptions } from '../models/types';
/**
 * 验证错误
 */
export declare class ValidationError extends Error {
    constructor(message: string);
}
/**
 * 验证视频文件
 * @param filePath 文件路径
 * @param fileSize 文件大小（字节）
 */
export declare function validateVideoFile(filePath: string, fileSize: number): void;
/**
 * 验证发布选项
 * @param options 发布选项
 */
export declare function validatePublishOptions(options?: VideoPublishOptions): void;
/**
 * 清理 hashtag（移除 # 前缀）
 * @param hashtag 原始 hashtag
 * @returns 清理后的 hashtag
 */
export declare function cleanHashtag(hashtag: string): string;
/**
 * 格式化 hashtag 数组为字符串
 * @param hashtags hashtag 数组
 * @returns 格式化后的字符串
 */
export declare function formatHashtags(hashtags?: string[]): string;
declare const _default: {
    validateVideoFile: typeof validateVideoFile;
    validatePublishOptions: typeof validatePublishOptions;
    cleanHashtag: typeof cleanHashtag;
    formatHashtags: typeof formatHashtags;
    ValidationError: typeof ValidationError;
};
export default _default;
//# sourceMappingURL=validator.d.ts.map