import winston from 'winston';
/**
 * 创建 Logger 实例的工厂函数
 * @param moduleName 模块名称，用于日志标识
 * @returns winston Logger 实例
 */
export declare function createLogger(moduleName: string): winston.Logger;
export declare const logger: winston.Logger;
declare const _default: {
    createLogger: typeof createLogger;
    logger: winston.Logger;
};
export default _default;
//# sourceMappingURL=logger.d.ts.map