"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
exports.createLogger = createLogger;
const winston_1 = __importDefault(require("winston"));
const dotenv_1 = __importDefault(require("dotenv"));
// 加载环境变量
dotenv_1.default.config();
/**
 * 获取日志级别，默认为 info
 */
const getLogLevel = () => {
    return process.env.LOG_LEVEL || 'info';
};
/**
 * 创建日志格式
 */
const createLogFormat = (moduleName) => {
    return winston_1.default.format.combine(winston_1.default.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }), winston_1.default.format.printf(({ timestamp, level, message }) => {
        return `[${timestamp}] [${level.toUpperCase()}] [${moduleName}] ${message}`;
    }));
};
/**
 * 创建 Logger 实例的工厂函数
 * @param moduleName 模块名称，用于日志标识
 * @returns winston Logger 实例
 */
function createLogger(moduleName) {
    const logLevel = getLogLevel();
    const logFormat = createLogFormat(moduleName);
    const logger = winston_1.default.createLogger({
        level: logLevel,
        format: logFormat,
        transports: [
            // Console transport
            new winston_1.default.transports.Console({
                format: winston_1.default.format.combine(winston_1.default.format.colorize(), logFormat),
            }),
            // File transport
            new winston_1.default.transports.File({
                filename: 'app.log',
                format: logFormat,
            }),
        ],
    });
    return logger;
}
// 导出默认 logger
exports.logger = createLogger('App');
exports.default = { createLogger, logger: exports.logger };
//# sourceMappingURL=logger.js.map