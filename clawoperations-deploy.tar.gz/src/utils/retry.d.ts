import { RetryConfig } from '../models/types';
/**
 * 带指数退避的重试工具函数
 * @param fn 需要执行的异步函数
 * @param config 重试配置（可选）
 * @returns Promise<T>
 */
export declare function withRetry<T>(fn: () => Promise<T>, config?: Partial<RetryConfig>): Promise<T>;
declare const _default: {
    withRetry: typeof withRetry;
};
export default _default;
//# sourceMappingURL=retry.d.ts.map