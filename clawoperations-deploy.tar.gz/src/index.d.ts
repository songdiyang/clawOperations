import { DouyinClient } from './api/douyin-client';
import { DouyinAuth, OAUTH_SCOPES } from './api/auth';
import { PublishService } from './services/publish-service';
import { SchedulerService } from './services/scheduler-service';
import { DouyinConfig, PublishTaskConfig, PublishResult, ScheduleResult, VideoPublishOptions, UploadProgress, TokenInfo } from './models/types';
import { createLogger } from './utils/logger';
export * from './models/types';
export { DouyinClient, DouyinAuth, OAUTH_SCOPES };
export { PublishService, SchedulerService };
export { createLogger };
/**
 * ClawPublisher - 抖音视频发布主类
 *
 * 提供统一的对外接口，供 ClawBot 或其他系统集成调用
 */
export declare class ClawPublisher {
    private client;
    private auth;
    private publishService;
    private schedulerService;
    /**
     * 创建 ClawPublisher 实例
     * @param config 抖音配置
     */
    constructor(config: DouyinConfig);
    /**
     * 获取授权页面 URL
     * @param scopes 授权作用域
     * @param state 状态参数
     * @returns 授权 URL
     */
    getAuthUrl(scopes?: string[], state?: string): string;
    /**
     * 处理授权回调，获取 Token
     * @param code 授权码
     * @returns Token 信息
     */
    handleAuthCallback(code: string): Promise<TokenInfo>;
    /**
     * 刷新 Token
     * @returns 新的 Token 信息
     */
    refreshToken(): Promise<TokenInfo>;
    /**
     * 检查 Token 是否有效
     * @returns 是否有效
     */
    isTokenValid(): boolean;
    /**
     * 获取当前 Token 信息
     * @returns Token 信息
     */
    getTokenInfo(): TokenInfo | null;
    /**
     * 上传视频文件
     * @param filePath 视频文件路径
     * @param onProgress 进度回调
     * @returns 视频 ID
     */
    uploadVideo(filePath: string, onProgress?: (progress: UploadProgress) => void): Promise<string>;
    /**
     * 从 URL 上传视频
     * @param videoUrl 视频 URL
     * @returns 视频 ID
     */
    uploadFromUrl(videoUrl: string): Promise<string>;
    /**
     * 发布视频（上传 + 发布）
     * @param config 发布任务配置
     * @returns 发布结果
     */
    publishVideo(config: PublishTaskConfig): Promise<PublishResult>;
    /**
     * 发布已上传的视频
     * @param videoId 视频 ID
     * @param options 发布选项
     * @returns 发布结果
     */
    publishUploadedVideo(videoId: string, options?: VideoPublishOptions): Promise<PublishResult>;
    /**
     * 下载远程视频并发布
     * @param videoUrl 视频 URL
     * @param options 发布选项
     * @returns 发布结果
     */
    downloadAndPublish(videoUrl: string, options?: VideoPublishOptions): Promise<PublishResult>;
    /**
     * 定时发布视频
     * @param config 发布任务配置
     * @param publishTime 发布时间
     * @returns 任务信息
     */
    scheduleVideo(config: PublishTaskConfig, publishTime: Date): ScheduleResult;
    /**
     * 取消定时任务
     * @param taskId 任务 ID
     * @returns 是否成功取消
     */
    cancelSchedule(taskId: string): boolean;
    /**
     * 列出所有定时任务
     * @returns 任务列表
     */
    listScheduledTasks(): ScheduleResult[];
    /**
     * 查询视频状态
     * @param videoId 视频 ID
     * @returns 视频状态
     */
    queryVideoStatus(videoId: string): Promise<{
        status: string;
        shareUrl?: string;
        createTime?: number;
    }>;
    /**
     * 删除视频
     * @param videoId 视频 ID
     */
    deleteVideo(videoId: string): Promise<void>;
    /**
     * 停止所有定时任务
     */
    stop(): void;
}
export default ClawPublisher;
//# sourceMappingURL=index.d.ts.map