/**
 * 默认配置常量
 */
export declare const API_CONFIG: {
    /** 抖音开放平台 API 基地址 */
    BASE_URL: string;
};
export declare const UPLOAD_CONFIG: {
    /** 分片上传阈值 (128MB) */
    CHUNK_UPLOAD_THRESHOLD: number;
    /** 默认分片大小 (5MB) */
    DEFAULT_CHUNK_SIZE: number;
};
export declare const RETRY_CONFIG: {
    /** 最大重试次数 */
    MAX_RETRIES: number;
    /** 基础延迟时间 (毫秒) */
    BASE_DELAY: number;
    /** 最大延迟时间 (毫秒) */
    MAX_DELAY: number;
};
export declare const VIDEO_CONFIG: {
    /** 支持的视频格式 */
    SUPPORTED_FORMATS: string[];
    /** 视频大小限制 (4GB) */
    MAX_SIZE: number;
};
export declare const CONTENT_CONFIG: {
    /** 标题最大长度 */
    MAX_TITLE_LENGTH: number;
    /** 描述最大长度 */
    MAX_DESCRIPTION_LENGTH: number;
    /** hashtag 最大数量 */
    MAX_HASHTAG_COUNT: number;
};
declare const _default: {
    API_CONFIG: {
        /** 抖音开放平台 API 基地址 */
        BASE_URL: string;
    };
    UPLOAD_CONFIG: {
        /** 分片上传阈值 (128MB) */
        CHUNK_UPLOAD_THRESHOLD: number;
        /** 默认分片大小 (5MB) */
        DEFAULT_CHUNK_SIZE: number;
    };
    RETRY_CONFIG: {
        /** 最大重试次数 */
        MAX_RETRIES: number;
        /** 基础延迟时间 (毫秒) */
        BASE_DELAY: number;
        /** 最大延迟时间 (毫秒) */
        MAX_DELAY: number;
    };
    VIDEO_CONFIG: {
        /** 支持的视频格式 */
        SUPPORTED_FORMATS: string[];
        /** 视频大小限制 (4GB) */
        MAX_SIZE: number;
    };
    CONTENT_CONFIG: {
        /** 标题最大长度 */
        MAX_TITLE_LENGTH: number;
        /** 描述最大长度 */
        MAX_DESCRIPTION_LENGTH: number;
        /** hashtag 最大数量 */
        MAX_HASHTAG_COUNT: number;
    };
};
export default _default;
//# sourceMappingURL=default.d.ts.map