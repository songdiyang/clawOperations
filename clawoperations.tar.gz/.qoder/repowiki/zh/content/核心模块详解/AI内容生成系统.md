# AI内容生成系统

<cite>
**本文档引用的文件**
- [README.md](file://README.md)
- [package.json](file://package.json)
- [src/index.ts](file://src/index.ts)
- [config/default.ts](file://config/default.ts)
- [src/models/types.ts](file://src/models/types.ts)
- [src/api/auth.ts](file://src/api/auth.ts)
- [src/services/publish-service.ts](file://src/services/publish-service.ts)
- [src/services/scheduler-service.ts](file://src/services/scheduler-service.ts)
- [src/utils/logger.ts](file://src/utils/logger.ts)
- [src/services/ai/content-generator.ts](file://src/services/ai/content-generator.ts)
- [src/services/ai/copywriting-generator.ts](file://src/services/ai/copywriting-generator.ts)
- [src/services/ai/requirement-analyzer.ts](file://src/services/ai/requirement-analyzer.ts)
- [web/server/src/index.ts](file://web/server/src/index.ts)
- [web/server/src/routes/ai.ts](file://web/server/src/routes/ai.ts)
- [web/client/src/pages/AICreator.tsx](file://web/client/src/pages/AICreator.tsx)
</cite>

## 目录
1. [项目概述](#项目概述)
2. [项目结构](#项目结构)
3. [核心组件](#核心组件)
4. [架构概览](#架构概览)
5. [详细组件分析](#详细组件分析)
6. [依赖关系分析](#依赖关系分析)
7. [性能考虑](#性能考虑)
8. [故障排除指南](#故障排除指南)
9. [结论](#结论)

## 项目概述

AI内容生成系统是一个基于抖音（TikTok）平台的智能内容创作和发布管理系统。该系统集成了AI技术，能够自动分析用户需求、生成图片和视频内容，并创建推广文案，最终实现内容的自动化发布。

### 主要特性

- **AI智能创作**：支持需求分析、内容生成、文案创作的完整工作流
- **多平台支持**：基于抖音开放平台API，支持视频上传和发布
- **定时发布**：提供cron表达式的定时发布功能
- **前后端分离**：采用React前端和Node.js后端架构
- **企业级配置**：支持环境变量配置和多种AI服务集成

**章节来源**
- [README.md:1-152](file://README.md#L1-L152)

## 项目结构

系统采用模块化的项目结构，主要分为以下几个核心部分：

```mermaid
graph TB
subgraph "前端应用 (web/client)"
A[React前端应用]
B[Ant Design UI组件]
C[API客户端]
end
subgraph "后端服务 (web/server)"
D[Express服务器]
E[路由控制器]
F[业务逻辑层]
end
subgraph "核心库 (src)"
G[发布管理器]
H[认证模块]
I[发布服务]
J[定时服务]
end
subgraph "AI服务"
K[需求分析器]
L[内容生成器]
M[文案生成器]
end
A --> D
B --> A
C --> D
D --> E
E --> F
F --> G
G --> H
G --> I
G --> J
F --> K
F --> L
F --> M
```

**图表来源**
- [src/index.ts:29-67](file://src/index.ts#L29-L67)
- [web/server/src/index.ts:11-55](file://web/server/src/index.ts#L11-L55)

**章节来源**
- [package.json:1-38](file://package.json#L1-L38)
- [src/index.ts:1-248](file://src/index.ts#L1-L248)

## 核心组件

### 发布管理器 (ClawPublisher)

ClawPublisher是系统的核心入口类，提供了统一的对外接口，负责协调各个子系统的协作。

```mermaid
classDiagram
class ClawPublisher {
-DouyinClient client
-DouyinAuth auth
-PublishService publishService
-SchedulerService schedulerService
+constructor(config)
+getAuthUrl(scopes, state) string
+handleAuthCallback(code) TokenInfo
+uploadVideo(filePath, onProgress) string
+publishVideo(config) PublishResult
+scheduleVideo(config, publishTime) ScheduleResult
+stop() void
}
class PublishService {
-VideoUpload videoUpload
-VideoPublish videoPublish
-DouyinAuth auth
+publishVideo(config) PublishResult
+uploadVideo(filePath, onProgress) string
+downloadAndPublish(url, options) PublishResult
}
class SchedulerService {
-PublishService publishService
-Map~string, ScheduledTask~ tasks
+schedulePublish(config, time) ScheduleResult
+cancelSchedule(taskId) boolean
+listScheduledTasks() ScheduleResult[]
+stopAll() void
}
ClawPublisher --> PublishService : "使用"
ClawPublisher --> SchedulerService : "使用"
PublishService --> VideoUpload : "组合"
PublishService --> VideoPublish : "组合"
```

**图表来源**
- [src/index.ts:29-67](file://src/index.ts#L29-L67)
- [src/services/publish-service.ts:22-31](file://src/services/publish-service.ts#L22-L31)
- [src/services/scheduler-service.ts:23-29](file://src/services/scheduler-service.ts#L23-L29)

### AI服务组件

系统集成了多个AI服务，包括需求分析、内容生成和文案创作：

```mermaid
classDiagram
class RequirementAnalyzer {
-DeepSeekClient deepseekClient
-string defaultContentType
+analyze(userInput) RequirementAnalysis
+quickAnalyze(userInput, contentType) RequirementAnalysis
}
class ContentGenerator {
-DoubaoClient doubaoClient
-string imageSize
-number videoDuration
-string videoResolution
+generate(analysis, onProgress) GeneratedContent
+checkTaskStatus(taskId) TaskStatus
}
class CopywritingGenerator {
-DeepSeekClient deepseekClient
-number maxTitleLength
-number maxDescriptionLength
-number maxHashtagCount
+generate(analysis) GeneratedCopywriting
+quickGenerate(theme, keyPoints) GeneratedCopywriting
+optimize(existingCopy, suggestions) GeneratedCopywriting
}
RequirementAnalyzer --> DeepSeekClient : "使用"
ContentGenerator --> DoubaoClient : "使用"
CopywritingGenerator --> DeepSeekClient : "使用"
```

**图表来源**
- [src/services/ai/requirement-analyzer.ts:25-34](file://src/services/ai/requirement-analyzer.ts#L25-L34)
- [src/services/ai/content-generator.ts:38-54](file://src/services/ai/content-generator.ts#L38-L54)
- [src/services/ai/copywriting-generator.ts:30-47](file://src/services/ai/copywriting-generator.ts#L30-L47)

**章节来源**
- [src/index.ts:29-244](file://src/index.ts#L29-L244)
- [src/services/ai/requirement-analyzer.ts:1-128](file://src/services/ai/requirement-analyzer.ts#L1-L128)
- [src/services/ai/content-generator.ts:1-229](file://src/services/ai/content-generator.ts#L1-L229)
- [src/services/ai/copywriting-generator.ts:1-194](file://src/services/ai/copywriting-generator.ts#L1-L194)

## 架构概览

系统采用分层架构设计，实现了清晰的关注点分离：

```mermaid
graph TB
subgraph "表现层"
UI[React前端界面]
API[RESTful API]
end
subgraph "控制层"
AuthCtrl[认证控制器]
AICtrl[AI创作控制器]
PubCtrl[发布控制器]
end
subgraph "业务层"
AIPubService[AI发布服务]
PubService[发布服务]
SchedulerService[定时服务]
end
subgraph "数据访问层"
DouyinClient[抖音API客户端]
DoubaoClient[豆包AI客户端]
DeepSeekClient[DeepSeek客户端]
end
UI --> API
API --> AuthCtrl
API --> AICtrl
API --> PubCtrl
AuthCtrl --> AIPubService
AICtrl --> AIPubService
PubCtrl --> PubService
AIPubService --> PubService
PubService --> SchedulerService
AIPubService --> DoubaoClient
AIPubService --> DeepSeekClient
PubService --> DouyinClient
```

**图表来源**
- [web/server/src/routes/ai.ts:14-58](file://web/server/src/routes/ai.ts#L14-L58)
- [src/services/publish-service.ts:27-31](file://src/services/publish-service.ts#L27-L31)
- [src/services/scheduler-service.ts:27-29](file://src/services/scheduler-service.ts#L27-L29)

**章节来源**
- [web/server/src/index.ts:1-55](file://web/server/src/index.ts#L1-L55)
- [web/server/src/routes/ai.ts:1-323](file://web/server/src/routes/ai.ts#L1-L323)

## 详细组件分析

### 认证系统

认证系统基于OAuth 2.0协议，支持授权码模式和刷新令牌机制：

```mermaid
sequenceDiagram
participant Client as "客户端"
participant Auth as "认证服务"
participant API as "抖音API"
participant Token as "令牌存储"
Client->>Auth : 请求授权URL
Auth->>API : 生成授权链接
API-->>Client : 返回授权页面
Client->>API : 用户授权
API->>Auth : 回调授权码
Auth->>API : 交换access_token
API-->>Auth : 返回令牌信息
Auth->>Token : 存储令牌
Auth-->>Client : 返回TokenInfo
```

**图表来源**
- [src/api/auth.ts:45-91](file://src/api/auth.ts#L45-L91)
- [src/api/auth.ts:98-127](file://src/api/auth.ts#L98-L127)

认证系统的关键特性：
- 支持多种OAuth作用域
- 自动令牌刷新机制
- 令牌有效期检查
- 安全的状态参数验证

**章节来源**
- [src/api/auth.ts:1-190](file://src/api/auth.ts#L1-L190)

### 发布流程

发布服务实现了完整的视频发布流程，包括上传、验证和发布三个阶段：

```mermaid
flowchart TD
Start([开始发布]) --> Validate[验证发布参数]
Validate --> CheckType{是否远程URL?}
CheckType --> |是| UploadFromUrl[从URL上传]
CheckType --> |否| UploadLocal[本地文件上传]
UploadFromUrl --> CreateVideo[创建视频]
UploadLocal --> CreateVideo
CreateVideo --> Success[发布成功]
Validate --> |参数无效| Error[返回错误]
UploadFromUrl --> |上传失败| Error
UploadLocal --> |上传失败| Error
CreateVideo --> |发布失败| Error
Error --> End([结束])
Success --> End
```

**图表来源**
- [src/services/publish-service.ts:38-80](file://src/services/publish-service.ts#L38-L80)
- [src/services/publish-service.ts:101-125](file://src/services/publish-service.ts#L101-L125)

发布流程的关键特性：
- 支持本地文件和远程URL两种上传方式
- 自动文件验证和大小检查
- 详细的进度回调机制
- 异常情况下的资源清理

**章节来源**
- [src/services/publish-service.ts:1-228](file://src/services/publish-service.ts#L1-L228)

### 定时发布系统

定时发布系统基于node-cron实现，提供了灵活的任务调度功能：

```mermaid
classDiagram
class SchedulerService {
-PublishService publishService
-Map~string, ScheduledTask~ tasks
+schedulePublish(config, time) ScheduleResult
+cancelSchedule(taskId) boolean
+listScheduledTasks() ScheduleResult[]
+executeTask(taskId) void
+dateToCron(date) string
}
class ScheduledTask {
+string id
+PublishTaskConfig config
+Date scheduledTime
+ScheduledTask cronJob
+string status
+unknown result
}
SchedulerService --> ScheduledTask : "管理"
SchedulerService --> PublishService : "调用"
```

**图表来源**
- [src/services/scheduler-service.ts:23-66](file://src/services/scheduler-service.ts#L23-L66)
- [src/services/scheduler-service.ts:140-162](file://src/services/scheduler-service.ts#L140-L162)

定时系统的核心功能：
- 基于cron表达式的精确调度
- 任务状态跟踪和管理
- 自动任务清理机制
- 全局任务停止功能

**章节来源**
- [src/services/scheduler-service.ts:1-202](file://src/services/scheduler-service.ts#L1-L202)

### AI创作工作流

AI创作系统实现了从需求分析到内容发布的完整自动化流程：

```mermaid
sequenceDiagram
participant User as "用户"
participant API as "AI API"
participant Analyzer as "需求分析器"
participant Generator as "内容生成器"
participant Copywriter as "文案生成器"
participant Publisher as "发布服务"
User->>API : 提交创作需求
API->>Analyzer : 分析用户输入
Analyzer-->>API : 返回分析结果
API->>Generator : 生成内容
Generator-->>API : 返回生成内容
API->>Copywriter : 生成文案
Copywriter-->>API : 返回文案
API-->>User : 返回完整创作结果
User->>API : 选择发布
API->>Publisher : 执行发布
Publisher-->>API : 返回发布结果
```

**图表来源**
- [web/server/src/routes/ai.ts:158-191](file://web/server/src/routes/ai.ts#L158-L191)
- [src/services/ai/content-generator.ts:62-102](file://src/services/ai/content-generator.ts#L62-L102)
- [src/services/ai/copywriting-generator.ts:54-74](file://src/services/ai/copywriting-generator.ts#L54-L74)

AI工作流的关键特性：
- 支持自动内容类型选择
- 多阶段进度反馈
- 错误处理和重试机制
- 与发布系统的无缝集成

**章节来源**
- [web/server/src/routes/ai.ts:1-323](file://web/server/src/routes/ai.ts#L1-L323)
- [src/services/ai/content-generator.ts:1-229](file://src/services/ai/content-generator.ts#L1-L229)
- [src/services/ai/copywriting-generator.ts:1-194](file://src/services/ai/copywriting-generator.ts#L1-L194)

## 依赖关系分析

系统的主要依赖关系如下：

```mermaid
graph TB
subgraph "外部依赖"
Axios[Axios HTTP客户端]
Winston[Winston日志库]
NodeCron[Node-Cron定时器]
Dotenv[Dotenv环境变量]
end
subgraph "核心模块"
Index[src/index.ts]
Types[src/models/types.ts]
Config[config/default.ts]
end
subgraph "服务层"
Auth[src/api/auth.ts]
Publish[src/services/publish-service.ts]
Scheduler[src/services/scheduler-service.ts]
Logger[src/utils/logger.ts]
end
subgraph "AI服务"
ReqAnalyzer[src/services/ai/requirement-analyzer.ts]
ContentGen[src/services/ai/content-generator.ts]
Copywriter[src/services/ai/copywriting-generator.ts]
end
subgraph "Web层"
Server[web/server/src/index.ts]
Routes[web/server/src/routes/ai.ts]
Client[web/client/src/pages/AICreator.tsx]
end
Axios --> Auth
Winston --> Logger
NodeCron --> Scheduler
Dotenv --> Config
Index --> Auth
Index --> Publish
Index --> Scheduler
Publish --> Auth
Publish --> Logger
Scheduler --> Publish
ReqAnalyzer --> Logger
ContentGen --> Logger
Copywriter --> Logger
Server --> Routes
Routes --> ReqAnalyzer
Routes --> ContentGen
Routes --> Copywriter
Routes --> Publish
Client --> Server
```

**图表来源**
- [package.json:18-33](file://package.json#L18-L33)
- [src/index.ts:1-20](file://src/index.ts#L1-L20)
- [web/server/src/index.ts:1-10](file://web/server/src/index.ts#L1-L10)

**章节来源**
- [package.json:1-38](file://package.json#L1-L38)
- [config/default.ts:1-70](file://config/default.ts#L1-L70)

## 性能考虑

### 并发处理
- 使用Promise.all实现异步操作的并发执行
- 合理的超时设置避免长时间阻塞
- 进度回调机制提供实时反馈

### 资源管理
- 自动清理临时文件和资源
- 连接池管理和复用
- 内存使用监控和优化

### 缓存策略
- 令牌缓存减少API调用
- 生成内容的本地缓存
- 配置信息的内存缓存

## 故障排除指南

### 常见问题及解决方案

**认证失败**
- 检查客户端密钥和密钥是否正确配置
- 验证回调URL是否与平台设置一致
- 确认网络连接和防火墙设置

**内容生成超时**
- 检查AI服务的API密钥配置
- 验证网络连接和带宽
- 查看AI服务的配额限制

**视频上传失败**
- 确认文件格式和大小限制
- 检查磁盘空间和权限
- 验证网络连接稳定性

**定时任务异常**
- 检查系统时间和时区设置
- 验证cron表达式的正确性
- 查看任务日志和错误信息

**章节来源**
- [src/utils/logger.ts:1-61](file://src/utils/logger.ts#L1-L61)
- [src/services/publish-service.ts:165-172](file://src/services/publish-service.ts#L165-L172)

## 结论

AI内容生成系统是一个功能完整、架构清晰的现代化内容创作平台。系统通过集成多种AI服务，实现了从需求分析到内容发布的完整自动化流程，大大提高了内容创作的效率和质量。

### 主要优势

1. **技术先进性**：集成了最新的AI技术和抖音平台API
2. **架构合理性**：采用分层架构，职责分离明确
3. **扩展性强**：模块化设计便于功能扩展和维护
4. **用户体验好**：提供直观的前端界面和流畅的操作体验

### 发展方向

1. **AI能力增强**：集成更多AI模型和服务
2. **多平台支持**：扩展到其他社交媒体平台
3. **自动化程度提升**：实现更智能的内容推荐和优化
4. **数据分析能力**：增加内容效果分析和优化建议

该系统为内容创作者和营销团队提供了一个强大而易用的工具，有助于在数字内容领域保持竞争优势。